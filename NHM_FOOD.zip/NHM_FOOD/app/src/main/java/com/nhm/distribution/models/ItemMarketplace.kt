package com.nhm.distribution.models

data class ItemMarketplace (
    val marketplace_id: Int,
    var name: String
)