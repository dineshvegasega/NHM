package com.nhm.distribution.models

data class ItemAds(
    val ad_sr_no: Int,
    val ad_type: Int,
    val ad_name: String,
    val ad_media: String,
    val ad_link: String
)