package com.nhm.distribution.models

data class ItemVending (
    val vending_id: Int,
    var name: String
)