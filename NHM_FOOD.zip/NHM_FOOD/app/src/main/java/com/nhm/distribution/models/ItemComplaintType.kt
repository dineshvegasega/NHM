package com.nhm.distribution.models

data class ItemComplaintType(
    val id: Int,
    var name: String
)
