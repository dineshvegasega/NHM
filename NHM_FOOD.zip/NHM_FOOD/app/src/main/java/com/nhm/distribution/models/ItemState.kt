package com.nhm.distribution.models

data class ItemState(
    val country_id: Int,
    val id: Int,
    var name: String
)