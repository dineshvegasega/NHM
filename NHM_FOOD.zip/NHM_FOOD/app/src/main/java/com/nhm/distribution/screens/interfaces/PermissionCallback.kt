package com.nhm.distribution.screens.interfaces

interface PermissionCallback {
    fun onPermissionGranted()
    fun onPermissionDenied()
}