package com.nhm.distribution.models

data class ItemReturn ( val position: Int = 0,
                        val name: String = "",
                        val title: String = "")