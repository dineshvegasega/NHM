package com.nhm.distribution.screens.interfaces

import android.content.Intent

interface SMSListener {
    fun onSuccess(intent : Intent?)
}
