package com.nhm.distribution.models

data class ItemPincode(
    val id: Int,
    val pincode: String,
    val district_id: Int
)
