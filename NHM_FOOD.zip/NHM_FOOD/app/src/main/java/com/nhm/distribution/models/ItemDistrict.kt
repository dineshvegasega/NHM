package com.nhm.distribution.models

data class ItemDistrict (
    val id: Int,
    var name: String,
    val state_id: Int,
    val Status: String
)