package com.nhm.distribution.screens.interfaces

interface CallBackListener {
    fun onCallBack(pos : Int = -1)
}